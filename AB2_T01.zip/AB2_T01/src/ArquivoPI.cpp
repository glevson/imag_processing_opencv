/*
 *      Author: Glevson da Silva Pinto
 */

#include <cv.h>
#include <highgui.h>
#include <iostream>

using namespace cv;
using namespace std;

Mat imgInfo(string texto, unsigned int larg, unsigned int alt);

Mat equalizaCanal_I(Mat img);
Mat saturaImagem(Mat img);
Mat mediana(Mat img);
Mat medianaCanal_I(Mat img);
Mat diferencaImagens(Mat img_1, Mat img_2);

int main( int argc, char ** argv ) {
	Mat img;
	img = imread("src/lena-original.tif", CV_LOAD_IMAGE_COLOR);
	if(img.empty()) {
		cout << "Imagem encontrada" << endl;
		return -1;
	}
	string nomeJanela = "Imagem";
	Mat equalizada = equalizaCanal_I(img);
	Mat saturada = saturaImagem(equalizada);
	Mat rgb_med = mediana(img);
	Mat hsi_med = medianaCanal_I(img);
	Mat img_diferenca = diferencaImagens(rgb_med, hsi_med);


//	imwrite("src/lena-diferenca_med_rgb_hsi.tif", img_diferenca);

	namedWindow(nomeJanela, CV_WINDOW_AUTOSIZE);

	imshow(nomeJanela, img);
	waitKey(0);


	imshow(nomeJanela, equalizada);
	waitKey(0);


	imshow(nomeJanela, saturada);
	waitKey(0);


	imshow(nomeJanela, rgb_med);
	waitKey(0);


	imshow(nomeJanela, hsi_med);
	waitKey(0);


	imshow(nomeJanela, img_diferenca);
	waitKey(0);

	destroyWindow(nomeJanela);

	return 0;
}

Mat imgInfo(string texto, unsigned int larg, unsigned int alt) {
	Scalar fundo = Scalar(220, 220, 220);
	Mat img_info(larg, alt, CV_8U, fundo);
	putText(img_info, texto, Point(10, alt/2),
				CV_FONT_HERSHEY_TRIPLEX, 1.0, Scalar(0, 0, 0));
	return img_info;
}

Mat equalizaCanal_I(Mat img) {
	Mat result, img_hsv;
	cvtColor(img, img_hsv, CV_RGB2HSV);
	vector<Mat> canais;
	split(img_hsv, canais);
	equalizeHist(canais[2], canais[2]);
	merge(canais, img_hsv);
	cvtColor(img_hsv, result, CV_HSV2RGB);
	return result;
}

Mat saturaImagem(Mat img) {
	Mat result;
	Mat canais[3];
	cvtColor(img, img, CV_RGB2HSV);
	split(img, canais);
	canais[1] *= 1.5;
	merge(canais, 3, result);
	cvtColor(result, result, CV_HSV2RGB);
	return result;
}

Mat mediana(Mat img) {
	Mat img_mediana;
	for ( int i = 1; i < 7; i = i + 2 ) {
		medianBlur( img, img_mediana, i);
	}
	return img_mediana;
}

Mat medianaCanal_I(Mat img) {
	Mat result, img_hsi;
	cvtColor(img, img_hsi, CV_RGB2HSV);
	vector<Mat> canais;
	split(img_hsi, canais);
	canais[2] = mediana(canais[2]);
	merge(canais, img_hsi);
	cvtColor(img_hsi, result, CV_HSV2RGB);
	return result;
}

Mat diferencaImagens(Mat img_1, Mat img_2) {
	Mat result;
	absdiff(img_1, img_2, result);
	return result;
}
