#include <cv.h>
#include <highgui.h>

using namespace cv;

int maiorValor(Mat img);

int main() {
	Mat img = imread("src/Figura4.tif", CV_LOAD_IMAGE_COLOR);
	Mat gaussiano, laplaciano, limiar;

	GaussianBlur(img, gaussiano, Size(3, 3), 0, 0, BORDER_DEFAULT);
	Laplacian(gaussiano, laplaciano, CV_8U, 3, 1, 0, BORDER_DEFAULT);
	threshold(laplaciano, limiar, maiorValor(laplaciano) * 0.9, 255, CV_THRESH_BINARY);

	imwrite("src/1 - gaussiano.tif", gaussiano);
	imwrite("src/2 - laplaciano.tif", laplaciano);
	imwrite("src/3 - final.tif", limiar);

	string nomeJan = "Imagem";
	namedWindow(nomeJan, CV_WINDOW_AUTOSIZE);
	imshow(nomeJan, img); // Original
	waitKey(0);
	imshow(nomeJan, gaussiano);
	waitKey(0);
	imshow(nomeJan, laplaciano);
	waitKey(0);
	imshow(nomeJan, limiar);
	waitKey(0);

	return 0;
}

int maiorValor(Mat img) {
	Mat cinza;
	cvtColor(img, cinza, CV_RGB2GRAY);
	int absoluto = 0.0;
	for (int linha = 0; linha < cinza.rows; linha++) {
		for (int col = 0; col < cinza.cols; col++) {
			if (absoluto < cinza.row(linha).col(col).at<uchar>(0))
				absoluto = cinza.row(linha).col(col).at<uchar>(0);
		}
	}
	return absoluto;
}
