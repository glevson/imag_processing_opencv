#include <cv.h>
#include <highgui.h>

using namespace cv;

int media(Mat img) {
	long soma = 0;
	for (int i = 0; i < img.rows; i++) {
		for (int j = 0; j < img.cols; j++) {
			soma += img.row(i).col(j).at<uchar>(0);
		}
	}
	return soma/(img.rows * img.cols);
}

int main() {

	Mat img = imread("src/Figura5.tif", CV_LOAD_IMAGE_GRAYSCALE);
	Mat limiar;
	threshold(img, limiar, media(img), 255, CV_THRESH_BINARY);

//	imwrite("src/Limiarização_global.tif", limiar);

	namedWindow("Digital", CV_WINDOW_AUTOSIZE);
	imshow("Digital", img);
	waitKey(0);
	imshow("Digital", limiar);
	waitKey(0);
	return 0;
}
