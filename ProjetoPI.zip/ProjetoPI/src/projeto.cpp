#include <cv.h>
#include <highgui.h>
#include <iostream>

using namespace cv;
using namespace std;

Mat imgInfo(string texto, unsigned int larg, unsigned int alt);

int main( int argc, char ** argv ) {
	Mat imgem = imread("src/lena-original.tif", CV_LOAD_IMAGE_COLOR);


	if(imgem.empty()) {
		cout << "Nenhuma Imagem encontrada" << endl;
		return -1;
	}
	string nomeJanela = "Lena";
	
	Mat img_hsi;
	Mat canais_hsi[3];
	Mat equalizada, saturada, rgb_med, hsi_med, img_diferenca;
	cvtColor(imgem, img_hsi, CV_RGB2HSV);
	split(img_hsi, canais_hsi);

	// Equalização
	equalizeHist(canais_hsi[2], canais_hsi[2]);
	merge(canais_hsi, 3, equalizada);
	cvtColor(equalizada, equalizada, CV_HSV2RGB);
	
	// Saturada
	canais_hsi[1] *= 1.7;
	merge(canais_hsi, 3, saturada);
	cvtColor(saturada, saturada, CV_HSV2RGB);

	// Mediana RGB
	for (int i = 1; i < 7; i = i + 2) {
		medianBlur(imgem, rgb_med, i);
	}

	// Mediana HSI
	split(img_hsi, canais_hsi);
	Mat imagem;
	for (int i = 1; i < 7; i = i + 2) {
		medianBlur(canais_hsi[2], imagem, i);
		canais_hsi[2]=imagem;
	}
	merge(canais_hsi, 3, hsi_med);
	cvtColor(hsi_med, hsi_med, CV_HSV2RGB);

	// Diferença
	absdiff(rgb_med, hsi_med, img_diferenca);

	//Salvar Imagens
	imwrite("src/lena-equalizada.tif", equalizada);
	imwrite("src/lena-saturada.tif", saturada);
	imwrite("src/lena-mediana_rgb.tif", rgb_med);
	imwrite("src/lena-mediana_hsi.tif", hsi_med);
	imwrite("src/lena-diferenca_med_rgb_hsi.tif", img_diferenca);

	namedWindow(nomeJanela, CV_WINDOW_AUTOSIZE);
	imshow(nomeJanela, imgInfo("Original", imgem.cols, imgem.rows));
	waitKey(0);
	imshow(nomeJanela, imgem);
	waitKey(0);

	imshow(nomeJanela, imgInfo("Canal I equalizado", imgem.cols, imgem.rows));
	waitKey(0);
	imshow(nomeJanela, equalizada);
	waitKey(0);

	imshow(nomeJanela, imgInfo("Equalizada e Saturada", imgem.cols, imgem.rows));
	waitKey(0);
	imshow(nomeJanela, saturada);
	waitKey(0);

	imshow(nomeJanela, imgInfo("Mediana RGB", imgem.cols, imgem.rows));
	waitKey(0);
	imshow(nomeJanela, rgb_med);
	waitKey(0);

	imshow(nomeJanela, imgInfo("Mediana HSI", imgem.cols, imgem.rows));
	waitKey(0);
	imshow(nomeJanela, hsi_med);
	waitKey(0);

	imshow(nomeJanela, imgInfo("Diferenca medianas", imgem.cols, imgem.rows));
	waitKey(0);
	imshow(nomeJanela, img_diferenca);
	waitKey(0);

	destroyWindow(nomeJanela);

	return 0;
}

Mat imgInfo(string texto, unsigned int larg, unsigned int alt) {
	Scalar fundo = Scalar(220, 220, 220);
	Mat img_info(larg, alt, CV_8U, fundo);
	putText(img_info, texto, Point(10, alt/2),
				CV_FONT_HERSHEY_TRIPLEX, 1.0, Scalar(0, 0, 0));
	return img_info;
}
